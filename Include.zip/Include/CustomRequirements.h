﻿///If lhs=rhs, returns true
req Equal : 0x1020 lhs rhs

req IsStage : 0x1021 ID
