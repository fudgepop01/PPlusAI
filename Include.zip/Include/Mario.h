//Automatically collected from OpenSA wiki.
/// Fireball
sact SpecialN : 0x1CE
/// Aerial Fireball
sact SpecialAirN : 0x1CF
/// Cape
sact SpecialS : 0x1D0
/// Aerial Cape
sact SpecialAirS : 0x1D1
/// Super Jump Punch
sact SpecialHi : 0x1D2
/// Aerial Super Jump Punch
sact SpecialAirHi : 0x1D3
/// FLUDD Startup
sact SpecialLwStart : 0x1D4
/// FLUDD Charge
sact SpecialLwHold : 0x1D5
/// FLUDD Release
sact SpecialLwLight : 0x1D6
/// FLUDD Full relese
sact SpecialLwHeavy : 0x1D7
/// FLUDD Air Startup
sact SpecialAirLwStart : 0x1D8
/// FLUDD Air Charge
sact SpecialAirLwHold : 0x1D9
/// FLUDD Air release
sact SpecialAirLwLight : 0x1DA
/// FLUDD Full Air release
sact SpecialAirLwHeavy : 0x1DB
/// Mario Finale
sact Final : 0x1DC
/// Mario Finale in the air
sact FinalAir : 0x1DD
