act GroundCombo : 0x4010
act AerialCombo : 0x4020
